fx_version 'cerulean' -- Use the latest FiveM version
game 'gta5' -- Specify the game

author 'Wock Development' -- Your development team
description 'No Ammo Counter Hud' -- A brief description of your resource
version '1.0.0' -- Version of your script

client_script 'client.lua' -- The script file you created