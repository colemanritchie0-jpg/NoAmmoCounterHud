Citizen.CreateThread(function()
while true do -- Exists so it runs every frame (while true means all the time, basically)
DisplayAmmoThisFrame(false) -- Using the native to disable it 
Citizen.Wait(0) -- Waiting 0ms to make the loop run every single frame with no exceptions
end
end)